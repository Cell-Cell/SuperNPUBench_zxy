# Issue #216 复现材料：group_token_vec_mt addtpc 基址错位

## 环境
- 工具链: linx-toolchain-build @ e6a31ef (clang 15.0.4, linx64v5-unknown-linux-musl)
- 仿真器: SuperScalarModel @ ef8e58e8 (main, 2026-08-18)
- 平台: aarch64 linux

## 复现
```bash
export SIM_DIR=<path>/SuperScalarModel
bash repro.sh
```

## 预期
gfrun 正常跑完，gfsim 打印完 SuperScalar Report。

## 实际
- gfrun: SIGSEGV (signal 11, exit 139)
- gfsim: Deadlock (SIGABRT, signal 6, exit 134)

## 文件
- elfs/: 预编译 ELF
- src/: 源码（hpp + cpp + Makefile）
- logs/: gfrun/gfsim 运行日志
- evidence/: 反汇编、段表、符号表、崩溃点
- repro.sh: 复现脚本
