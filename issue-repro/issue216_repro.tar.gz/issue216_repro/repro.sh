#!/bin/bash
# Issue #216 复现脚本：group_token_vec_mt addtpc 基址错位
# 需求：已构建的 SuperScalarModel（gfrun/gfsim）
set -e
SIM_DIR="${SIM_DIR:-$(pwd)/../../../SuperScalarModel}"
ELF="elfs/group_token_vec_mt.elf"

echo "===== gfrun（功能模型）====="
"$SIM_DIR/bin/gfrun" -f "$ELF" 2>&1 | tail -20
echo "gfrun exit: $?"

echo ""
echo "===== gfsim（时序模型，需 fourpe 配置）====="
cd "$SIM_DIR"
"$SIM_DIR/bin/gfsim" -f "$(pwd)/../issue216_repro/$ELF" --conf fourpe --pto-v02 true 2>&1 | tail -20
echo "gfsim exit: $?"
