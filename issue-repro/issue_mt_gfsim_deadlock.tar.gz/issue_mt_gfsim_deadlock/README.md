# 多线程算子 gfsim Deadlock 复现材料

## 问题概述

`SuperNPUBench` 的 4-PE SPMD 多线程算子在 `SuperScalarModel` 时序模型 `gfsim` 上触发 Deadlock，根因为 gfsim group layer 时序模型不完整（GMOVFabricResp 被 drop、IQ wake-up 仅 logical-ready）。

详细分析见 [ISSUE.md](ISSUE.md)。

## 目录结构

```
issue_mt_gfsim_deadlock/
├── ISSUE.md                          # 问题说明（现象、根因、修复建议）
├── README.md                         # 本文件
├── src/                              # 源码
│   ├── common/                       # 公共依赖（_start.s, Makefile.common, 链接脚本, 头文件）
│   ├── group_token_old/              # group_token_old 源码（hpp + cpp + Makefile）
│   └── group_token_vec_mt/           # group_token_vec_mt 源码（hpp + cpp + Makefile）
├── build_artifacts/                  # 预编译产物
│   ├── group_token_old/              # .elf + .o
│   └── group_token_vec_mt/           # .elf + .o
├── logs/                             # 运行日志
│   ├── group_token_old_gfrun.log     # gfrun 通过
│   ├── group_token_old_gfsim.log     # gfsim Deadlock
│   ├── group_token_vec_mt_gfrun.log  # gfrun SIGSEGV (issue #216)
│   └── group_token_vec_mt_gfsim.log  # gfsim Deadlock
├── evidence/                         # 证据材料
│   ├── group_token_old_disasm.txt    # 反汇编
│   ├── group_token_old_sections.txt  # 段表
│   ├── group_token_vec_mt_disasm.txt # 反汇编
│   └── group_token_vec_mt_sections.txt # 段表
└── scripts/
    ├── run_prebuilt.sh               # 免编译复现（用预编译 ELF）
    └── build_and_run.sh              # 源码编译+复现
```

## 快速复现

### 方式一：免编译（推荐）

```bash
export SIM_DIR=<path>/SuperScalarModel
bash scripts/run_prebuilt.sh
```

### 方式二：源码编译

```bash
export COMPILER_DIR=<path>/linx-toolchain-build/output/linx_blockisa_llvm_musl/bin
export SIM_DIR=<path>/SuperScalarModel
bash scripts/build_and_run.sh
```

## 预期结果

| 算子 | gfrun | gfsim |
|---|---|---|
| group_token_old | PASS (exit 0) | Deadlock (exit 134) |
| group_token_vec_mt | SIGSEGV (exit 139, issue #216) | Deadlock (exit 134) |

## 环境

- 工具链: linx-toolchain-build @ e6a31ef (clang 15.0.4)
- 仿真器: SuperScalarModel @ ef8e58e8 (main, 2026-08-18)
- 平台: aarch64 linux
