# [Bug] 多线程算子 gfsim Deadlock：group layer 时序模型不完整导致 4-PE SPMD 算子无法仿真

## 摘要

`SuperNPUBench/benchmark/one-level-arch` 的两个多线程算子（`group_token_old`、`group_token_vec_mt`）编译通过后，在 `SuperScalarModel` 时序模型 `gfsim` 上均触发 Deadlock 中止。其中 `group_token_old` 在功能模型 `gfrun` 上可正常跑完，`group_token_vec_mt` 在 `gfrun` 上另触发 SIGSEGV（该 SIGSEGV 属于 issue #216 的 addtpc page-rounding 缺陷，与本 issue 独立）。

本 issue 聚焦 **gfsim group layer 时序模型不完整** 导致的 Deadlock 问题。

## 环境

| 项 | 值 |
|---|---|
| 算子仓 | `SuperNPUBench`（v300_tag_0818 工作区），`benchmark/one-level-arch/kernels/group_token_old` + `test/kernel/multi_thread/group_token_old` |
| 算子仓 | `SuperNPUBench`（v300_tag_0818 工作区），`benchmark/one-level-arch/kernels/group_token_vec_mt` + `test/kernel/multi_thread/group_token_vec` |
| 工具链 | `linx-toolchain-build` @ `e6a31ef`（clang 15.0.4, `linx64v5-unknown-linux-musl`） |
| 仿真器 | `SuperScalarModel` @ `ef8e58e8`（main, 2026-08-18 构建） |
| 运行参数 | gfsim: `--conf fourpe --pto-v02 true`（4-PE SPMD 必需） |
| 平台 | aarch64 linux |
| 日期 | 2026-08-18 |

## 算子说明

两个算子均为 **4-PE SPMD 多线程 MoE Token 分组算子**：

- **group_token_old**：TLOAD + 标量计数，Phase-1 清零 → Phase-2 分组统计 → Phase-3 输出
- **group_token_vec_mt**：TLOAD + tile-op 计数变体，多线程版 group_token_vec

两者均使用 `BSTART.TLSU`/`STD COND` 等 block 指令进行 4-PE 间的数据协调。

## 问题现象

### group_token_old

| 仿真器 | 结果 | 详情 |
|---|---|---|
| gfrun | **通过** | `Success to Reach the End of Benchmark! R2 = 0`（12311 blocks / 139147 insts） |
| gfsim | **Deadlock** | `Deadlock detected at thread 1, cycles=4318, 7 blocks verified, 0 minsts verified`（SIGABRT, exit 134） |

### group_token_vec_mt

| 仿真器 | 结果 | 详情 |
|---|---|---|
| gfrun | **SIGSEGV** | signal 11, exit 139（属 issue #216 addtpc page-rounding 缺陷，非本 issue） |
| gfsim | **Deadlock** | `Deadlock detected at thread 1, cycles=4318, 7 blocks verified, 0 minsts verified`（SIGABRT, exit 134） |

### gfsim Deadlock 详情

```
[C:4317   ][DFX.NA    ]: Deadlock detected at thread 1, cycles=4318, waitCycles exceeded threshold, verified blocks=7, verified minsts=0
[C:4317   ][BCC.STAGE ]:     |--B18 STID0 BPC 0x112f0 [STD COND] STD allocated<- oldest/commitPtr
[C:4317   ][BCC.STAGE ]:     |--B19 STID0 BPC 0x112f0 [STD COND] STD allocated<- nonFlushBid
[C:4317   ][BCC.STAGE ]:     |--B20 STID0 BPC 0x112f0 [STD COND] STD allocated
[C:4317   ][BCC.STAGE ]:     |--B21 STID0 BPC 0x112f0 [STD COND] STD allocated
[C:4317   ][BCC.STAGE ]:     |--B22 STID0 BPC 0x112f0 [STD COND] STD allocated
B18 STID0 BPC 0x112f0 [STD COND] STD allocated
[C:4317   ][BCC.STAGE ]:     |--B7 STID1 BPC 0x1146c [STD COND] STD allocated<- oldest/commitPtr<- nonFlushBid
[C:4317   ][BCC.STAGE ]:     |--B8 STID1 BPC 0x11482 [STD DIRECT] STD allocated
[C:4317   ][BCC.STAGE ]:     |--B9 STID1 BPC 0x1145e [STD COND] STD allocated
```

关键特征：
- **STD COND 块卡在 `allocated` 状态**，无法推进到 `completed`
- `verified blocks=7, verified minsts=0` — 7 个 block 已分配但 0 个 minst 完成验证
- hand 全部 `deallocPtr:0 retirePtr:0` — 没有任何 CELL 被释放或退役
- 死锁发生在 cycle 4318（极早期，算子核心逻辑尚未执行）

## 根因分析

### 1. gfsim group layer 为 first-pass stub

`SuperScalarModel` 的 AGENTS.md 明确记录 group layer 是 first-pass 实现，多个关键路径未接通：

| 模块 | 状态 | 影响 |
|---|---|---|
| GMOVFabricResp | **被 drop**（无 CellReg writeback） | GMOV 跨 PE 数据传输完成后，目标 PE 无法收到数据 |
| GMMA datapath | **fixed-latency stub** | 矩阵计算生命周期未接入真实 CUBE 时序 |
| IQ wake-up | **logical-ready only** | IQ 唤醒仅逻辑就绪，不真正触发 issue |
| GroupCommitGate | **4-thread lockstep** | 要求 4 线程同步提交，但前置条件无法满足 |

### 2. 失效链路

```
BSTART.STD COND (4-PE 协调块)
  → GroupDispatchGate: 检查 GGC 状态
  → GGC 未就绪（GMOVFabricResp 被 drop 导致 GGC count 未归零）
  → STD COND 块停在 allocated，无法进入 issue/commit
  → 后续所有块因 ROB 顺序约束被阻塞
  → waitCycles 超阈值 → Deadlock 检测触发
```

### 3. 与 issue #216 的关系

`group_token_vec_mt` 同时存在两个独立问题：

| 问题 | 触发点 | 根因 | 所属 issue |
|---|---|---|---|
| gfrun SIGSEGV | 初始化段（Phase-1 清零，PC 0x1146e） | addtpc page-rounding 基址错位 | #216 |
| gfsim Deadlock | 算子执行段（cycle 4318） | group layer 不完整 | **本 issue** |

修复 #216 后，gfrun SIGSEGV 消除，但 gfsim Deadlock 仍会触发（因 group layer 问题独立存在）。

### 4. 排除算子侧问题

- `group_token_old` 在 gfrun 上完整跑通 12311 blocks，证明算子功能正确
- 单线程变体 `group_token_vec`（相同 kernel）在 gfrun/gfsim 上均通过（27544 blocks）
- 问题仅在 4-PE SPMD 多线程模式下出现

## 复现步骤

### 方式一：免编译（使用预编译 ELF）

```bash
tar xzf issue_mt_gfsim_deadlock.tar.gz
cd issue_mt_gfsim_deadlock
export SIM_DIR=<path>/SuperScalarModel
bash scripts/run_prebuilt.sh
```

### 方式二：源码编译

```bash
export COMPILER_DIR=<path>/linx-toolchain-build/output/linx_blockisa_llvm_musl/bin
export SIM_DIR=<path>/SuperScalarModel
bash scripts/build_and_run.sh
```

### 预期结果

- gfrun: `Success to Reach the End of Benchmark! R2 = 0`
- gfsim: 完整输出 SuperScalar Report

### 实际结果

- group_token_old: gfrun 通过，gfsim Deadlock（exit 134）
- group_token_vec_mt: gfrun SIGSEGV（exit 139，issue #216），gfsim Deadlock（exit 134）

## 修复建议

1. **补全 GMOVFabricResp 写回路径**：当前 `Core::Work::Tick()` 返回的 `GMOVFabricResp` 被直接 drop（AGENTS.md §11 已记录），需通过 `VecTileRegStReq` 写回 CellReg，使 GMOV 跨 PE 传输真正完成
2. **接通 IQ wake-up apply**：当前 `iqPtr→entry` 唤醒仅 logical-ready，需将逻辑就绪转化为实际 issue 触发
3. **验证 GMMA lifecycle**：当前为 fixed-latency stub，需接入真实 CUBE/B-staging datapath timing
4. **修复后回归**：需验证全部多线程算子套件（group_token_old, group_token_vec_mt, matmul, fa, vec/tadd, vec/trowsum）

## 影响面

所有 4-PE SPMD 多线程算子在 gfsim 上均不可运行：

| 算子 | gfrun | gfsim |
|---|---|---|
| group_token_old | ✓ | ✗ Deadlock |
| group_token_vec_mt | ✗ SIGSEGV (#216) | ✗ Deadlock |
| matmul | ✗ 超时 | ✗ assertion |
| fa | ✗ 编译失败 | — |
| vec/tadd | ✓ | ✓ |
| vec/trowsum | ✓ | ✗ Deadlock |

仅 `vec/tadd`（纯标量无 group 协调）在 gfsim 上通过，进一步印证 group layer 是失效根因。
