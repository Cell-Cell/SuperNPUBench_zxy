#!/bin/bash
# run_prebuilt.sh — 使用预编译 ELF 复现多线程 gfsim Deadlock
# 依赖：已构建的 SuperScalarModel（gfrun/gfsim）
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SIM_DIR="${SIM_DIR:-$(cd "$ROOT_DIR/../../../SuperScalarModel" 2>/dev/null && pwd)}"

if [ -z "${SIM_DIR:-}" ] || [ ! -x "$SIM_DIR/bin/gfrun" ]; then
    echo "ERROR: SIM_DIR not set or gfrun not found."
    echo "Usage: export SIM_DIR=<path>/SuperScalarModel && bash scripts/run_prebuilt.sh"
    exit 1
fi

GFRUN="$SIM_DIR/bin/gfrun"
GFSIM="$SIM_DIR/bin/gfsim"

ELF_OLD="$ROOT_DIR/build_artifacts/group_token_old/kernel_multi_thread_group_token_old_group_token_old.elf"
ELF_VEC="$ROOT_DIR/build_artifacts/group_token_vec_mt/group_token_vec_mt.elf"

PASS=0
FAIL=0

run_case() {
    local name="$1" elf="$2" runner="$3" runner_name="$4" expect_pass="$5"
    echo "========== $name / $runner_name =========="
    timeout 120 "$runner" -f "$elf" "${@:6}" 2>&1 | tail -15
    local exit_code=$?
    echo "exit_code=$exit_code"
    if [ "$expect_pass" = "true" ] && [ $exit_code -eq 0 ]; then
        echo "RESULT: PASS (as expected)"
        PASS=$((PASS + 1))
    elif [ "$expect_pass" = "false" ] && [ $exit_code -ne 0 ]; then
        echo "RESULT: FAIL (as expected — reproduces the issue)"
        FAIL=$((FAIL + 1))
    else
        echo "RESULT: UNEXPECTED"
    fi
    echo ""
}

echo "############################################"
echo "# Multi-thread gfsim Deadlock Reproduction"
echo "# Simulator: $SIM_DIR"
echo "############################################"
echo ""

# group_token_old: gfrun should pass
run_case "group_token_old" "$ELF_OLD" "$GFRUN" "gfrun" "true"

# group_token_old: gfsim should deadlock (exit 134)
cd "$SIM_DIR"
run_case "group_token_old" "$ELF_OLD" "$GFSIM" "gfsim" "false" "--conf" "fourpe" "--pto-v02" "true"
cd "$ROOT_DIR"

# group_token_vec_mt: gfrun SIGSEGV (issue #216, exit 139)
run_case "group_token_vec_mt" "$ELF_VEC" "$GFRUN" "gfrun" "false"

# group_token_vec_mt: gfsim should deadlock (exit 134)
cd "$SIM_DIR"
run_case "group_token_vec_mt" "$ELF_VEC" "$GFSIM" "gfsim" "false" "--conf" "fourpe" "--pto-v02" "true"
cd "$ROOT_DIR"

echo "############################################"
echo "Summary: PASS=$PASS, FAIL=$FAIL"
echo "  group_token_old  gfrun  : PASS (expected)"
echo "  group_token_old  gfsim  : Deadlock (issue reproduced)"
echo "  group_token_vec_mt gfrun: SIGSEGV (issue #216)"
echo "  group_token_vec_mt gfsim: Deadlock (issue reproduced)"
echo "############################################"
