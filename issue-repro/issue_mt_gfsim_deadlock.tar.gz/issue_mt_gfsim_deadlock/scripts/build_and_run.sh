#!/bin/bash
# build_and_run.sh — 从源码编译多线程算子并复现 gfsim Deadlock
# 依赖：已构建的 linx-toolchain-build 和 SuperScalarModel
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SIM_DIR="${SIM_DIR:-$(cd "$ROOT_DIR/../../../SuperScalarModel" 2>/dev/null && pwd)}"
COMPILER_DIR="${COMPILER_DIR:-$(cd "$ROOT_DIR/../../../linx-toolchain-build/output/linx_blockisa_llvm_musl/bin" 2>/dev/null && pwd)}"

if [ -z "${COMPILER_DIR:-}" ] || [ ! -x "$COMPILER_DIR/clang++" ]; then
    echo "ERROR: COMPILER_DIR not set or clang++ not found."
    echo "Usage: export COMPILER_DIR=<path>/linx-toolchain-build/output/linx_blockisa_llvm_musl/bin"
    exit 1
fi
if [ -z "${SIM_DIR:-}" ] || [ ! -x "$SIM_DIR/bin/gfrun" ]; then
    echo "ERROR: SIM_DIR not set or gfrun not found."
    echo "Usage: export SIM_DIR=<path>/SuperScalarModel"
    exit 1
fi

GFRUN="$SIM_DIR/bin/gfrun"
GFSIM="$SIM_DIR/bin/gfsim"
SNPUBENCH="$ROOT_DIR/../../.."

echo "############################################"
echo "# Build and Reproduce Multi-thread gfsim Deadlock"
echo "# Compiler: $COMPILER_DIR"
echo "# Simulator: $SIM_DIR"
echo "############################################"
echo ""

# Build group_token_old
echo "===== 1/4 Compile group_token_old ====="
make -C "$SNPUBENCH/test/kernel/multi_thread/group_token_old" \
    TESTCASE=group_token_old COMPILER_DIR="$COMPILER_DIR" clean 2>&1 | tail -1
make -C "$SNPUBENCH/test/kernel/multi_thread/group_token_old" \
    TESTCASE=group_token_old COMPILER_DIR="$COMPILER_DIR" 2>&1 | tail -3
ELF_OLD=$(find "$SNPUBENCH/output/kernel/multi_thread/group_token_old/elf" -name "*.elf" | head -1)
echo "ELF: $ELF_OLD"
echo ""

# Build group_token_vec_mt
echo "===== 2/4 Compile group_token_vec_mt ====="
make -C "$SNPUBENCH/test/kernel/multi_thread/group_token_vec" \
    TESTCASE=group_token_vec_mt COMPILER_DIR="$COMPILER_DIR" clean 2>&1 | tail -1
make -C "$SNPUBENCH/test/kernel/multi_thread/group_token_vec" \
    TESTCASE=group_token_vec_mt COMPILER_DIR="$COMPILER_DIR" 2>&1 | tail -3
ELF_VEC=$(find "$SNPUBENCH/output/kernel/multi_thread/group_token_vec/elf" -name "*.elf" | head -1)
echo "ELF: $ELF_VEC"
echo ""

# Run group_token_old
echo "===== 3/4 Run group_token_old ====="
echo "--- gfrun ---"
timeout 60 "$GFRUN" -f "$ELF_OLD" 2>&1 | tail -6
echo "gfrun exit: $?"
echo "--- gfsim ---"
cd "$SIM_DIR"
timeout 90 "$GFSIM" -f "$ELF_OLD" --conf fourpe --pto-v02 true 2>&1 | grep -iE "deadlock|assert|fatal|cycle|Report Stop" | head -5
echo "gfsim exit: $?"
cd "$ROOT_DIR"
echo ""

# Run group_token_vec_mt
echo "===== 4/4 Run group_token_vec_mt ====="
echo "--- gfrun ---"
timeout 30 "$GFRUN" -f "$ELF_VEC" 2>&1 | tail -6
echo "gfrun exit: $?"
echo "--- gfsim ---"
cd "$SIM_DIR"
timeout 90 "$GFSIM" -f "$ELF_VEC" --conf fourpe --pto-v02 true 2>&1 | grep -iE "deadlock|assert|fatal|cycle|Report Stop" | head -5
echo "gfsim exit: $?"
cd "$ROOT_DIR"
echo ""

echo "############################################"
echo "Expected results:"
echo "  group_token_old  gfrun  : PASS (exit 0)"
echo "  group_token_old  gfsim  : Deadlock (exit 134)"
echo "  group_token_vec_mt gfrun: SIGSEGV (exit 139, issue #216)"
echo "  group_token_vec_mt gfsim: Deadlock (exit 134)"
echo "############################################"
