#!/bin/bash
# 新问题复现：多线程 group_token_old gfsim Deadlock（group layer 不完整）
set -e
SIM_DIR="${SIM_DIR:-$(pwd)/../../../SuperScalarModel}"
ELF="elfs/group_token_old_mt.elf"

echo "===== gfrun（功能模型，通过）====="
"$SIM_DIR/bin/gfrun" -f "$ELF" 2>&1 | tail -10
echo "gfrun exit: $?"

echo ""
echo "===== gfsim（时序模型，Deadlock）====="
cd "$SIM_DIR"
"$SIM_DIR/bin/gfsim" -f "$(pwd)/../issue_new_mt_deadlock_repro/$ELF" --conf fourpe --pto-v02 true 2>&1 | grep -iE "deadlock|block|assert|fatal|cycle" | head -15
echo "gfsim exit: $?"
