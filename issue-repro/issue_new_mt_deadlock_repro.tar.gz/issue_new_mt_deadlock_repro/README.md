# 新问题复现材料：多线程算子 gfsim Deadlock（group layer 不完整）

## 环境
- 工具链: linx-toolchain-build @ e6a31ef (clang 15.0.4)
- 仿真器: SuperScalarModel @ ef8e58e8 (main, 2026-08-18)
- 平台: aarch64 linux

## 复现
```bash
export SIM_DIR=<path>/SuperScalarModel
bash repro.sh
```

## 现象
- gfrun: 通过（12311 blocks, R2=0）
- gfsim: Deadlock @ cycle 4318, thread 1, 7 blocks verified, 0 minsts verified
  - STD COND 卡在 allocated 状态，无法推进到 completed
  - 根因: gfsim group layer 为 first-pass stub，GMOVFabricResp 被 drop，IQ wake-up 仅 logical-ready

## 文件
- elfs/: 预编译 ELF
- src/: 源码
- logs/: gfrun(通过) + gfsim(Deadlock) 日志
- evidence/: 反汇编、段表
- repro.sh: 复现脚本
